
package StefanoTutorial4Task1;

public class Main {

    public static void main(String[] args) 
    {               
        Square square = new Square();
        square.caluclateArea();
        
        Circle circle = new Circle();
        circle.caluclateArea();
    }    
}

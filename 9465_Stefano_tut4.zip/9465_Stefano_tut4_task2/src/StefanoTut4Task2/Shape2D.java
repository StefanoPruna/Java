
package StefanoTut4Task2;


public interface Shape2D 
{
    public Float calculateDiameter();
    public Float calculateCircumference();
    public Float calculateArea();
    public Float showCharacteristcs();
}

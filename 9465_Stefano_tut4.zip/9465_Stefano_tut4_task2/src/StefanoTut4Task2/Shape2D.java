
package StefanoTut4Task2;


public interface Shape2D 
{
    public void calculateDiameter();
    public void calculateCircumference();
    public void calculateArea();
    public void showCharacteristcs();
}


package StefanoTut4Task2;


public interface Shape3D 
{
    public void calculateVolume();    
}


package BusinessLogic;

import java.util.ArrayList;
import java.util.List;
import javafx.scene.control.Label;

public class Calculate 
{  
    public Float result = 0f; 
//    public Float number;
}



/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stefano_tut1;

public class Stefano_tut1 {

    public static void main(String[] args) 
    {
        Stefano_9465_tut1_task1 questionOne = new Stefano_9465_tut1_task1();        
        questionOne.taskOne();
        
        Stefano_9465_tut1_task2 questionTwo = new Stefano_9465_tut1_task2();        
        questionTwo.taskTwo();
        
        Stefano_9465_tut1_task3 questionThree = new Stefano_9465_tut1_task3();
        questionThree.taskThree();
        
        System.exit(0);
    }
    
}

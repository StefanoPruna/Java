/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Stefano_tut1;

public class Stefano_tut1 
{
    public static void main(String[] args)
    {
        Tutorial1Task1 questionOne = new Tutorial1Task1();        
        questionOne.taskOne();
        
        Tutorial1Task2 questionTwo = new Tutorial1Task2();        
        questionTwo.taskTwo();
        
        Tutorial1Task3 questionThree = new Tutorial1Task3();
        questionThree.taskThree();
        
        System.exit(0);
    }
    
}


package StefanoTut8;

public class InsufficientFundsException extends Exception
{

    public InsufficientFundsException(String string) {
        super(string);
    }
    
}

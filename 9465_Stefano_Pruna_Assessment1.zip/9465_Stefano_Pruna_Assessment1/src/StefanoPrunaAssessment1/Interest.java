
package StefanoPrunaAssessment1;


public interface Interest 
{    
    public Float calculateInterest();    
}

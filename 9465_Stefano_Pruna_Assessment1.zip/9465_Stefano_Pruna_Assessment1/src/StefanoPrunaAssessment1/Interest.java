
package StefanoPrunaAssessment1;

//Interface for the 3 classes that calculate the interest besides the ChequeAccount class
public interface Interest 
{    
    public Float calculateInterest();    
}

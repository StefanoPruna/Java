
package StefanoTut2;

public class StefanoTutorial2 {

    public static void main(String[] args) 
    {
        Tutorial2Task1 questionOne = new Tutorial2Task1();       
        questionOne.taskOne();
        
        Tutorial2Task2 questionTwo = new Tutorial2Task2();
        questionTwo.taskTwo();
        
        Tutorial2Task3 questionThree = new Tutorial2Task3();
        questionThree.taskThree();
        
        Tutorial2Task4 questionFour = new Tutorial2Task4();
        questionFour.taskFour();
        
        System.exit(0);
    }
    
}

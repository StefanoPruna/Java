
package businessLogic;

public class InsufficientFundsException extends Exception
{

    public InsufficientFundsException(String string) {
        super(string);
    }    
}
